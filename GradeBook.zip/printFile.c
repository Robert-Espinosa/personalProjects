
/*BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I STRICTLY ADHERED TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. THIS IS THE README FILE FOR LAB 4. */
#include "lab4.h"
#include <stdlib.h>
#include <stdio.h>
void printFile(FILE* file, Node* person){
	
	//fprintf("%s\n", perseon->Student.student_name);
	//fprintf("%i\n", person->Student.student_ID);
	//fprintf("%f %f %f", person->Student.Cat1.score1, person->Student.Cat1.score2,  person->Student.Cat1.score3);
	//fprintf("%f %f %f", person->Student.Cat2.score1, person->Student.Cat2.score2,  person->Student.Cat2.score3);

	 //fprintf("%f %f %f", person->Student.Cat3.score1, person->Student.Cat3.score2,  person->Student.Cat3.score3);

 	//fprintf("%f %f %f", person->Student.Cat4.score1, person->Student.Cat4.score2,  person->Student.Cat4.score3);


}
